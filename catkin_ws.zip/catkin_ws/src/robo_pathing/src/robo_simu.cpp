#include "ros/ros.h"
#include <string>
#include <fstream>
#include "gio_path.cpp"

#define deltaT 0.1

int main(int argc, char **argv)
{

  ros::init(argc, argv, "simulator");
  ros::NodeHandle n;
  std::string param;
  n.getParam("simulator/file", param);

  ROS_INFO("%s", param.c_str());
  
  CGioController controller;
  controller.getPathFromFile(param.c_str());
  
  double u, w, vleft, vright;  //nextState returns
  double x, y, phi;		//currentPose
  controller.getPose(x,y,phi); //get start Pose
  std::string content("");
  //anweisungen von controller bekommen -> diese für deltaT ausführen -> neue anweisungen anfordern...
  double totalTime = 0;
  while(controller.getNextState(u,w,vleft,vright,0)){ //run controller until path is followed
  	double totalAngle = w * deltaT;		//calculate turn angle after deltaT
  	double deltaPosX,deltaPosY;
  	cerr<<totalAngle<<"\n";
  	if(abs(totalAngle)<=0.01){		//if the angle is small, assume a straight line as path
  		cerr<<"Line!\n";
  		deltaPosX = u*deltaT;
  		deltaPosY = 0;
  	}
  	else{						//else calculate the endpoint of the Kreisabschnitt where the robo comes to a stop
  		cerr<<"Curve!\n";
	  	double radius = (2*M_PI/totalAngle)*((u*deltaT)/(2*M_PI));
	  	deltaPosY = (radius*cos(totalAngle))-radius;
	  	deltaPosX = radius*sin(totalAngle);
  	}	
  	//Rotate the Vector to account for the robos rotation
  	double ROTdeltaPosX = cos(phi)*deltaPosX - sin(phi)*deltaPosY;
  	double ROTdeltaPosY = sin(phi)*deltaPosX + cos(phi)*deltaPosY;
  	
  	//apply the changes
  	x += ROTdeltaPosX;
  	y += ROTdeltaPosY;
  	phi += totalAngle;
  	NormalizeAngle(phi);
  	//controller.setCurrentVelocity(u,u);
  	controller.setPose(x,y,phi);
  	
  	//write to string
  	content.append(std::to_string(x));
  	content.append(" ");
  	content.append(std::to_string(y));
  	content.append(" ");
  	content.append(std::to_string(u));
  	content.append(",");
  	content.append(std::to_string(w));
  	content.append("\n");	
  	totalTime+=deltaT;
  }
  //write string to file
  std::ofstream out("plotting/outputSimulation.txt");
    out << content;
    out.close();
  //ros::spin();
  ros::shutdown();
  return 0;
}
