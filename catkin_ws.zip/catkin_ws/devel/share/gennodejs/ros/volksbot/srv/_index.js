
"use strict";

let velocities = require('./velocities.js')

module.exports = {
  velocities: velocities,
};
