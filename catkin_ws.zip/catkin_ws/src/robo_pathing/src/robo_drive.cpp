#include "ros/ros.h"
#include <string>
#include <fstream>
#include "nav_msgs/Odometry.h"
#include "gio_path.cpp"
#include "vels.h"//Manually copied in closeby includes folder from devel/include/volksbot/vels.h
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "tf/transform_datatypes.h"
//#include "LinearMath/btMatrix3x3.h"


double x, y, phi;
bool first = true;
double xOff, yOff, phiOff;
std::string paramC;
//Compute current position according to mode setting (no/ transformation to relative Coordinates)
void computePos(double xx, double yy, tf::Quaternion q){
if(paramC != "abs"){
	  double ox = xx;
	  double oy = yy;

	  tf::Matrix3x3 m(q);
	  double roll, pitch, yaw;
	  m.getRPY(roll, pitch, yaw);
	  phi = yaw;
	  
	  if(first){
	  	xOff = ox;
	  	yOff = oy;
	  	phiOff = phi;
	  	first = false;
	  }
	  ox-=xOff;
	  oy-=yOff;
	  x = cos(-phiOff)*ox - sin(-phiOff)*oy;
	  y = sin(-phiOff)*ox + cos(-phiOff)*oy;	
	  phi -= phiOff;
	  NormalizeAngle(phi);
	  }
  else{
  	x = xx;
  	y = yy;
  	tf::Matrix3x3 m(q);
  	double roll, pitch, yaw;
  	m.getRPY(roll, pitch, yaw);
  	phi = yaw;
  }
}
void amclCallback(const geometry_msgs::PoseWithCovarianceStamped& msg)
{
  tf::Quaternion q(
    msg.pose.pose.orientation.x,
    msg.pose.pose.orientation.y,
    msg.pose.pose.orientation.z,
    msg.pose.pose.orientation.w);
  computePos(msg.pose.pose.position.x, msg.pose.pose.position.y, q);
}
void odomCallback(const nav_msgs::Odometry& msg)
{   tf::Quaternion q(
     msg.pose.pose.orientation.x,
     msg.pose.pose.orientation.y,
     msg.pose.pose.orientation.z,
     msg.pose.pose.orientation.w);
    computePos(msg.pose.pose.position.x, msg.pose.pose.position.y, q);
}

int main(int argc, char **argv)
{

  ros::init(argc, argv, "driver");
  ros::NodeHandle n;
  //Get params
  std::string paramF;//Path to drive
  n.getParam("driver/file", paramF);
  std::string paramM;//AMCL/Odom mode
  n.getParam("driver/mode", paramM);
  n.getParam("driver/coord", paramC);//Abs/Rel coordinate mode
  if(paramC == "abs")
  	ROS_INFO("ABSOLUTE COORDINATE MODE!");
  else
  	ROS_INFO("RELATIVE COORDINATE MODE!");
  
  
  ros::Subscriber sub;
  if(paramM == "amcl") //use subscriber according to mode setting
  	sub = n.subscribe("/amcl_pose", 1000, amclCallback);
  else
  	sub = n.subscribe("/odom",1000, odomCallback);
  ros::Publisher joy_pub = n.advertise<volksbot::vels>("Vel", 1000);
  
  CGioController controller;
  controller.getPathFromFile(paramF.c_str());
  
  double u, w, vleft, vright; 
  ros::Rate loop_rate(10);
  //Controll loop
  while (ros::ok())
  {
  	if(!controller.getNextState(u,w,vleft,vright,0)) //if end of path is reached, stop
  		break;
  	volksbot::vels msg;
  	msg.left = vleft*-50; //Robot uses wheelspeeds between -30 and 30, the controller outputs negative values 
  	msg.right = vright*-50; //with much too low magnitudes. So we multiply both by a negative amount to correct that
  	msg.id = 0;
  	joy_pub.publish(msg);
  	
  	controller.setCurrentVelocity((vleft+vright)*0.5,1);
	controller.setPose(x,y,phi);
	ROS_INFO("Pos: %f, %f, %f",x,y,phi);
  	
  	ros::spinOnce();
    	loop_rate.sleep();
  }
  volksbot::vels msg;
  msg.left = 0.0;
  msg.right = 0.0;
  msg.id = 0;
  joy_pub.publish(msg);
  ros::shutdown();
  return 0;
}
