#include "ros/ros.h"
#include "std_msgs/String.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include <signal.h>
#include <string>
#include <fstream>

std::string odomContent("");
std::string amclContent("");
std::string paramM;

int odomCounter = 0;
int amclCounter = 0;

void mySigintHandler(int sig)
{
  // Save the collected data before shutting down
  std::string odomPlace = "plotting/outputOdom.txt";
  std::string amclPlace = "plotting/outputAMCL.txt";
  if(paramM == "abs"){
  	//change the File-Path to be more easily accesible in "abs" mode, so one can immediatly repeat the driven path
  	odomPlace = "PfadOdom.dat";
  	amclPlace = "PfadAMCL.dat";
  }	
      std::ofstream out1(odomPlace);
  if(paramM == "abs") out1 <<  odomCounter <<"\n";
  out1 << odomContent;
  out1.close();
  
  std::ofstream out2(amclPlace);
  if(paramM == "abs") out2 << amclCounter << "\n";
  out2 << amclContent;
  out2.close();
  ros::shutdown();
}

double xoO, yoO;
bool firstO = true;
void odomCallback(const nav_msgs::Odometry& msg)
{
  //Save offset on First Callback to calculate relative Position for "rel" mode
  if(firstO){
  	xoO = msg.pose.pose.position.x;
  	yoO = msg.pose.pose.position.y;
  	firstO = false;
  }
  if(paramM != "abs"){
  //"rel" mode
  odomContent.append(std::to_string(msg.pose.pose.position.x-xoO));
  odomContent.append(" ");
  odomContent.append(std::to_string(msg.pose.pose.position.y-yoO));
  odomContent.append("\n");
  }
  else{
  //"abs" mode
  odomCounter++;//abs mode is supposed to be used to Follow a path as the Robot has before driven it.
  //For that the total number of points on the Path needs to be know, so we save it as well.
  odomContent.append(std::to_string(msg.pose.pose.position.x));
  odomContent.append(" ");
  odomContent.append(std::to_string(msg.pose.pose.position.y));
  odomContent.append("\n");
  }
}

double xaO, yaO;
bool firstA = true;
void amclCallback(const geometry_msgs::PoseWithCovarianceStamped& msg)
{
  //Save offset on First Callback to calculate relative Position for "rel" mode
  if(firstA){
  	xaO = msg.pose.pose.position.x;
  	yaO = msg.pose.pose.position.y;
  	firstA = false;
  }
  if(paramM != "abs"){
  //"rel" mode
  amclContent.append(std::to_string(msg.pose.pose.position.x-xaO));
  amclContent.append(" ");
  amclContent.append(std::to_string(msg.pose.pose.position.y-yaO));
  amclContent.append("\n");
  }
  else{
  //"abs" mode
  amclCounter++; //abs mode is supposed to be used to Follow a path as the Robot has before driven it.
  //For that the total number of points on the Path needs to be know, so we save it as well.
  amclContent.append(std::to_string(msg.pose.pose.position.x));
  amclContent.append(" ");
  amclContent.append(std::to_string(msg.pose.pose.position.y));
  amclContent.append("\n");
  }
}

int main(int argc, char **argv)
{

  ros::init(argc, argv, "listener", ros::init_options::NoSigintHandler);
  ros::NodeHandle n;
  n.getParam("listener/mode", paramM);
  if(paramM == "abs")
  	ROS_INFO("ABSOLUTE COORDINATE MODE!");
  else
  	ROS_INFO("RELATIVE COORDINATE MODE!");
  signal(SIGINT, mySigintHandler);
  ros::Subscriber subOdo = n.subscribe("/odom", 1000, odomCallback);
  ros::Subscriber subAMCL = n.subscribe("/amcl_pose", 1000, amclCallback);

  
  ros::spin();

  return 0;
}
